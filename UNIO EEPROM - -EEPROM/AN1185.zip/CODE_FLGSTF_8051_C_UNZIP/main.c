// UNIO_C_8051_TIM06
 // MAIN.c  
 //***************************************************************************
 // File Name    : main.c 
 // Dependencies : unio_dec.h  = header in which are declared the necessary 
                                 // functions for a "bit-bang" method to 
                                 // interface a "MicroChip"s UNIO memory 
 //                unio_def.c = definitions of the above functions 
 //                REG952.h        = SFRs definitions offered by "Keil" 
 //                STARTUP950      = start-up code for LPC952 ( "Keil" )  
 // Processor    : P89LPC952  
 // Hardware     : MicroChip's UNIO EEPROM = 11XXX on MCB950 EVB . 
 // I.D.E.       : uVision3 - Keil 
 // Company      : MicroChip Technology , Inc. 
 // Author       : Alexandru Valeanu
 //...........................................................................
 //                   SOFTWARE  LICENSE AGREEMENT 
 //...........................................................................
 // "Microchip Technology Inc. (�Microchip�) licenses this software to you 
 // solely for use with Microchip Serial EEPROM products.  
 // The software is owned by Microchip and/or its licensors,and is protected 
 // under applicable copyright laws.  All rights reserved.
 // SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP AND ITS LICENSOR EXPRESSLY 
 // DISCLAIM ANY WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING 
 // BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS 
 // FOR A PARTICULAR PURPOSE,OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP 
 // AND ITS LICENSORS BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
 // CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, 
 // COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY 
 // CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE 
 // THEREOF),ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS."
 //***************************************************************************
 // History      :  V1.0 - First Release 
 //...........................................................................
 // File Description :  This is the main function for AN1185 . Demonstrates 
 //                     a possible Sw interface between P89LPC952 and 
 //                     MicroChip's UNIO EEPROM = 11xxx . 
 // Writes a source string in the 11xxx, reads it back in the destination
 // string, compares the 2 strings, presenting 2 types of messages : 
 // comparison error = flashes for ever 0x00 -0xff once / second (reads <> writes) 
 // o.k.  = shifts left one LED as sign of success(and gradualy lights the LEDs). 
 // During the sequence , the code displays the string's characters on LEDs
 // and on the UART1 line, for a visual control .
 // 2 methods are presented : random byte access mode and page access mode.
 // Any other blinking on LEDs, means an error on low level functions. 
 // The error codes are : 0xy0 + offset , 0xy4 + offset , 0xy8 + offset , 
 // 0xyc + offset, where the offset is introduced by : SAK , NOSAK , UNI_RDQ. 
 // OFFSET = +00 --> timeout in SAK / NOSAK  
 // OFFSET = +01 --> no edge inside SAK 
 // OFFSET = +02 --> a '0' spike inside NOSAK 
 // OFFSET = +03 --> no edge inside UNI_RDQ  ( serialization function for reads )
 // The full list of error messages can be found at the end of the 'main' function.    
 //******************************************************************************
    #include "REG952.h"
    #include "unio_dec.h"   

      void main(void)   
      { 
  	    #define  ADR0  0x0040          // initialization of the address 
        #define STRSZ      16          // size of the string 
        #define RND_MODE    0          // random byte access mode 
        #define  PG_MODE    1          //        page access mode 
// ..........................................................................
     unsigned char access_mode = RND_MODE ; // sets the access mode to RAND 
//   unsigned char access_mode =  PG_MODE ; // sets the access mode to PAGE 
     unsigned int adr_cnt        ;  // address counter  
     unsigned char ch_cnt        ;  // character counter inside  strings  
     unsigned char     ok        ;  // displays the "success" message
     unsigned char *src_str  = "C_UNI_BB_VFLEDTX" ;   
                                     // source string which will be written 
                                     // in the e2prom(C=language,UNI =
                                       // memory type, BB = bit-bang method, 
                                       // VFLEDTX = verif through LEDs & COM1 
        unsigned char dst_str[STRSZ];  // destination string,read from the eep  
        unsigned int n              ;  // variables used in the self variable 
        unsigned int duty           ;  // duty PWM ( OK message ) 
//����������������������������������������������������������������������������
                                       //  call all initialization routines 
        ini_intr()                  ;  //  interrupts'  init 
        ini_wdt()                   ;  //  W.D.T.'s     init 
        ini_osc()                   ;  //  oscillator's init   
        ini_gpio()                  ;  //  GPIO's       init  
        ini_com1()                  ;  //  UART1's      init 
        ini_tim()                   ;  //  Timers'      init 
        calctl0()                   ;  //  calculates tlqb / tlhb = TL0 for 
                                       //  quarter / half bit, based on QBUSEC     
        ini_unio()                  ;  //  init memory : WRSR = NOPROT = 00
// must be included test functions for ERAL , SETAL , CRRD .   
 //����������������������������������������������������������������������������
 // WRITE SOURCE STRING IN EEPROM 
 //............................................................................ 
	if(access_mode==RND_MODE)          // if RANDOM MODE    
    { ch_cnt=0 ; adr_cnt=ADR0       ;  // initialize char & address counters  
      while(ch_cnt<STRSZ)              // repeat till the end of the string 
 {uni_wrbyte(adr_cnt,src_str[ch_cnt]); // write a random byte 
      ch_cnt++  ;  adr_cnt++   ; }  }  // increment both counters      
      else 							   // if(PAGE_MODE) 
  { uni_wrstr(src_str,ADR0,STRSZ) ; }  // wr "src_str" from ADR0,size=STRSZ
 //����������������������������������������������������������������������������
 // READ EEPROM IN THE DESTINATION STRING 
 // ............................................................................ 
  if(access_mode==RND_MODE)            // in RANDOM MODE
  {ch_cnt=0    ;   adr_cnt=ADR0      ; // init both counters : char & address 
   while(ch_cnt<STRSZ)                 // repeat till the end of the string 
  {uni_rdbyte(adr_cnt,dst_str+ch_cnt); // fill the destination string with chrs 
   ch_cnt++  ;  adr_cnt++  ;  }      } // increment both counters (chr&address)         
   else 
  {uni_rdstr(dst_str,ADR0,STRSZ)  ;  } // in PAGE MODE , sequential read   
 //����������������������������������������������������������������������������
 // COMPARE SOURCE & DESTINATION STRINGS 
 //............................................................................     
   for(ch_cnt=0;ch_cnt<STRSZ;ch_cnt++) 
  {if((*(dst_str+ch_cnt)) != (*(src_str+ch_cnt))) 
                                       // compare the 2 strings(source & dest) 
     { while(1)                        // in case of mismatch 
       {P5=0x00 ; dly1s() ;            // flash forever 00 - ff , once / second 
        P5=0xff ; dly1s() ; }  }  
  else {P5=*(dst_str+ch_cnt)        ;  // if coincidence,display reads on LEDs  
        tx_com1(*(dst_str+ch_cnt))  ;  // send the read character on UART1 line 
//      dly1s()                     ;  // once /second for a visual control 
        dly250ms()                  ;  // 4 chars / second       
                            }       }  // repeat till the end of the string 
 //����������������������������������������������������������������������������
 //   ok = 0x01                       ;  // init the "display_success" variable .   
 //   while(1)                           //display forever a shifter,as sign of ok  
 // 	 {
      for(ok=0x01;ok;ok<<=1)
	     {P5=ok;dly250ms();}   
 //		                       }                            
 // An alternative to this "success" sequence is to gradualy light the 8 LEDs 
 // through a PWM with self-variable duty-cycle . Below , the possible code .
  #define  speed   0x010             // the speed of changinf the PWM ratio
  #define MAXDUTY  3000              // MAXDUTY steps for the PWM 
  while(1)  
  { n++ ; 
    if(n<duty) { P5=0xff ; } 
    else       { P5=0x00 ; }     
    if(n>MAXDUTY) { duty +=speed ; n=0x0000 ; } 
	if(duty>MAXDUTY) { duty=0x0000 ; } 
                                        }                    
                                  }
//**********************************************************************************
//                  LIST OF ERROR MESSAGES
//**********************************************************************************
// WRSR           START  ---------  0x00 + offset 
//               DEVADR  ---------  0x04 + offset 
//            WRSR cmnd  ---------  0x08 + offset 
//           wr in SReg  ---------  0x0c + offset 
//..................................................................................
// WRBYTE          WREN  ---------  0x10 + offset ( START,DEVADR,cmnd ) 
//                START  ---------  0x14 + offset 
//               DEVADR  ---------  0x18 + offset 
//              WR cmnd  ---------  0x1c + offset 
//              MSB adr  ---------  0x20 + offset 
//              LSB adr  ---------  0x24 + offset 
//            Data byte  ---------  0x28 + offset 
//.................................................................................                    
// WRSTRING        WREN  ---------  0x2c + offset ( START,DEVADR,cmnd ) 
//                START  ---------  0x30 + offset 
//               DEVADR  ---------  0x34 + offset 
//              WR cmnd  ---------  0x38 + offset 
//              MSB adr  ---------  0x3c + offset 
//              LSB adr  ---------  0x40 + offset 
//      (n-1)Data bytes  ---------  0x44 + offset
//       Last Data byte  ---------  0x48 + offset 
//.................................................................................
// RDBYTE         START	 ---------  0x4c + offset  
//               DEVADR	 ---------  0x50 + offset 
//              RD cmnd	 ---------  0x54 + offset 
//              MSB adr	 ---------  0x58 + offset 
//              LSB adr  ---------  0x5c + offset 
//            Data byte  ---------  0x60 + offset 
//................................................................................. 
// RDSTRING       START	 ---------  0x64 + offset  
//               DEVADR	 ---------  0x68 + offset 
//              RD cmnd	 ---------  0x6c + offset 
//              MSB adr	 ---------  0x70 + offset 
//              LSB adr  ---------  0x74 + offset 
//      (n-1)data bytes  ---------  0x78 + offset 
//       Last data byte  --------- 	0x7c + offset 
//*********************************************************************************

