//                  UNIO_DEF.C  - FUNCTIONS  DEFINITION 
 //****************************************************************************
 // File Name    : unio_def.c 
 // Dependencies : unio_dec.h = functions declaration  
 //                REG952.h     = SFRs definitions offered by "Keil" 
 //                STARTUP950   = start-up code for LPC952 ( "Keil" )  
 // Processor    : P89LPC952  
 // Hardware     : MicroChip's UNIO EEPROM = 11XXX on MCB950 EVB . 
 // I.D.E.       : uVision3 - Keil 
 // Company      : MicroChip Technology , Inc. 
 // Author       : Alexandru Valeanu
 //...........................................................................
 //                SOFTWARE  LICENSE AGREEMENT 
 //...........................................................................
 // "Microchip Technology Inc. (�Microchip�) licenses this software to you 
 // solely for use with Microchip Serial EEPROM products. 
 // The software is owned by Microchip and/or its licensors,and is protected 
 // under applicable copyright laws.  All rights reserved.
 // SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP AND ITS LICENSOR EXPRESSLY 
 // DISCLAIM ANY WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING 
 // BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS 
 // FOR A PARTICULAR PURPOSE,OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP 
 // AND ITS LICENSORS BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
 // CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, 
 // COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY 
 // CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE 
 // THEREOF),ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS."
 //***************************************************************************
 // History      :  V1.0 - Initial Release 
 //...........................................................................
 // File Description : This is the file defining all the necesary functions
 //                    for the application note AN1185 . 
 //                    Functions are declared in "i2c_bb_dec.h" and defined in
 // the below file . As described , there are 3 types of  functions : 
 // initialization , i2c_access , auxiliary . Moreover , the file defines 
 // the public variables ( byte & bit ) and all the UNI/O commands.                     
 //.............................................................................
    #include "REG952.h"
    #include "unio_dec.h" 
     sfr S1CONX = 0xB6  ;     // correct declaration of S1CON     
//.............................................................................
//                        GLOBAL CONSTANTS 
//............................................................................
     #define  STRSZ   16             //  string size 
	 #define  DEVADR  0xa0           //  slave address
     #define  START   0x55           //  start header 
     #define  READ    0x03           //  READ instruction 
     #define  CRRD    0x06           //  READ from crt address instruction 
     #define  WRITE   0x6c           //  WRITE instruction
     #define  WREN    0x96           //  WRITE ENABLE instruction 
     #define  WRDI    0x91           //  WRITE DISABLE instruction 
     #define  RDSR    0x05           //  READ STATUS register instruction 
     #define  WRSR    0x6e           //  WRITE STATUS REGISTER instruction 
     #define  ERAL    0x6d           //  ERASE entire array instruction 
     #define  SETAL   0x67           //  SET   entire array instruction 
     #define  NOPROT  0x00           //  disable all write protections
	 #define  timeout 30             //  test beginning SAK / NOSAK  
	 #define  QBUSEC  16             //  quarter bit = 16 usec ~ 12 Khz
//   #define  QBUSEC  12             //  quarter bit = 12 usec 
//   #define  QBUSEC   8             //  quarter bit = 08 usec
//   #define  QBUSEC   7 			 //  quarter bit = 07 usec 
//   #define  QBUSEC   6 			 //  quarter bit = 06 usec 
//   #define  QBUSEC   5             //  quarter bit = 05 usec   
//   #define  QBUSEC   4             //  quarter bit = 04 usec ~ 40 Khz
//   #define  QBUSEC   3             //  quarter bit = 03 usec ~ 46 Khz 
//	 #define  QBUSEC   2             //  quarter bit = 02 usec 
//............................................................................ 
//                          GLOBAL  VARIABLES
//............................................................................
	  unsigned char err_cnt           ; //  error counter       
      unsigned char bdata eep_buf     ; //  eeprom's data buffer  
            sbit shift7 = eep_buf^7   ; //  bit7 of  data buffer
            sbit shift0 = eep_buf^0   ; //  bit0 of  data buffer 
            sbit SCIO   = P1^3        ; //  definition of SCIO  
	  unsigned char load[STRSZ]       ; //  global string for "copystr" function
	  unsigned char tlqb              ; //  TL0 quarter bit  
	  unsigned char tlhb              ; //  TL0 half    bit  
//...........................................................................
//                           INITIALIZATION FUNCTIONS  
//...........................................................................
         void  ini_intr(void)  // interrupts'   init                       
    { // IEN0 = 0x00 ; 
      // IEN1 = 0x00 ; 
      // IEN2 = 0x00 ;         // disable all interrupts                        
                           }   //  reset value = 00 , disable intr

       void  ini_wdt(void)     // W.D.T.'s init - WDT disabled in UCFG1 
    {  WDCON = 0xe0          ; // WDCON = PRE210-xx-WDRUN-WDTOF-WDCLK  
       WDL   = 0xff          ; // roll-over at maximum 
       WFEED1 = 0xa5         ; // stop WDT even it's underflow reset is dis 
       WFEED2 = 0x5a         ; // feed sequence after WDCON write-intr dis
                           } 

       void  ini_osc(void)     // oscillator's init-TRIM=RCCLK-ENCLK-TRIM5,0 
    {  TRIM |= 0xc0         ;  // RCCLK=ENCLK=1 (trim value remains the same)                     
                               // enable CCLK:2 on XTAL2 = P3.0 
                           } 
    
       void  ini_gpio(void)    // GPIO's  init
    {  P0M1 = 0xff          ;  // P0 = analog apps , all bits = inputs 
       P0M2 = 0x00          ;   
       P1M1 = 0xfe          ;  // P1=I2C->P1.3=SDA=open dr,P1.2=SCL=open dr
	                           //         P1.3=SCIO    
       P1M2 = 0x0d          ;  // COM0->P1.1=RXD0=inp , P1.0=TXD0=push pull 
       P3M1 = 0x02          ;  // P3.1 = XTAL1 = inp 
       P3M2 = 0x01          ;  // P3.0 = CLKOUT= out push pull 
       P4M1 = 0x0a          ;  // P4.3=RXD1=inp , P4.2=TXD1=push pull , 
       P4M2 = 0x05          ;  // P4.1=TRIG=inp , P4.0=nCS =push pull . 
       P5M1 = 0x00          ;  // all P5's bits = bi - directional 
       P5M2 = 0x00          ;  // 
       P5   = 0x00        ; }  // clear all LEDs                            

       void ini_com1(void)    // UART1's      init
    {  
//     S1CON    = 0x52      ;  //SM01=01=8bUART-REN=1-TB8/RB8=00,TI=1,RI=0
       S1CONX   = 0x52      ;   
       BRG0_1   = 0xf0      ;  // BAUD=256*BRG1+BRG0+16 
       BRG1_1   = 0x02      ;  // 7.373Mhz : 9600 = 768 = 2*256+240+16 
       BRGCON_1 = 0x03      ;  // 9600 baud + 1b_start + 8b_date + 1b_stop  
                         }      

       void  ini_tim(void)     // Timers'  init
    {  TMOD = 0x22          ;  // T0,1 = MODE2 (8b auto-reload)  
                               // GATE0,1=0(delay timer_0 will start at TR0) 
                         }      
//.............................................................................  
//                 UNIO  ACCESS FUNCTIONS  DEFINITIONS 
//*****************************************************************************
    void mak(void) 
  { SCIO=0             ; 
    dlyhfbit()         ;    // MAK = 0 - 1
//  dlyhbp()           ;    // half bit plus   
    SCIO=1             ; 	
	dlyhfbit()         ;    // hfbit + hfbit
//  dlyhbp()           ;    // half bit plus 
                         }    
//.............................................................................
    void nomak(void) 
  { SCIO=1             ; 
    dlyhfbit()         ;    // NOMAK = 1 - 0
//  dlyhbp()           ;    // half bit plus  
    SCIO=0             ; 
	dlyhfbit()         ;    // hfbit + hfbit 
//  dlyhbp()           ;    // half bit plus 
                         } 
//.............................................................................
    void sak(void)           //  SAK = 0 - 1 
  { unsigned char wait = timeout ; // init timeout counter 
    SCIO=1; P1M2=0x05 ;      //  SCIO=1 + SCIO = input 
    while(SCIO)              //  wait SCIO=0 
	{ wait-- ;               //  decrement timeout counter  
	if(wait==0){ferror();} } //  if timeout , ferror   
    dlyhfbit();dlyhfbit()  ; //  next SCIO sample after 1 bit 
    if(SCIO==0)              //  if SCIO==0 , error 1 (SAK)  
    { err_cnt +=0x01  ;      //  err_cnt = err_cnt + 1  
        ferror()      ; } 	 //  ferror 
   else { P1M2 = 0x0d ; }  } //  if SCIO==1,continue,SCIO=out        
//.............................................................................
    void nosak(void)         //  NOSAK = 1 - 1 
  { unsigned char wait = timeout ; // init timeout counter 
    SCIO=1; P1M2=0x05 ;      //  SCIO=1 + SCIO=input 
    while(!SCIO)             //  wait SCIO=1 
	{ wait-- ; 
	if(wait==0){ferror();} } //  if timeout , ferror 
    dlyhfbit();dlyhfbit()  ; //  next SCIO sample after 1 bit     
    if(SCIO==0)              //  if SCIO=0 , error 2 (NOSAK)  
    { err_cnt +=0x02       ; //  err_cnt = err_cnt + 2  
        ferror()      ; } 	 //  ferror 
   else { P1M2=0x0d   ; } }  //  if SCIO=1,continue,SCIO=out      
//.............................................................................
        void uni_wr(void)                // writes an 8b streaming 
    { unsigned char bit_count = 0   ;    // bit counter for the 8b streaming 
        while(bit_count<8)               // for 8 bits 
        { SCIO = ~shift7            ;    // SCIO = cpl[bit_n(data_buf)]  
          dlyhfbit()                ;    // half bit delay 
//		  dlyhbp()                  ;    // increase HB1, to balance HB2 
          SCIO = shift7             ;    // SCIO= initial value of bit_n 
                                         // 1=(0-1) , 0=(1-0) 
          dlyhfbit()                ;    // half bit delay 
          eep_buf=eep_buf<<1        ;    // shift left 1bit the eep's data buf 
          bit_count++               ; }  // increment bit counter(repeat for 8b)                          
                                        } 
//............................................................................
        unsigned char uni_rdq(void)      // read an 8b streaming : QB + 3QB  
      { unsigned char bit_count = 0 ;    // bit counter for the 8b streaming 
        SCIO=1 ; P1M2=0x05          ;    // prepare SCIO as input (=1) 
        while(bit_count<8)   
   { eep_buf=eep_buf<<1             ;    // shift left 1b eeprom data buffer
	 dlyqbit()                      ;    // first SCIO sample at (1/4) bit    
  if(SCIO==0) 
    { 
	  dlyhfbit()                    ;    // wait (3/4) bit
//    dlyhbp()                      ;    // increase delay            
      if(SCIO==0) 
        {err_cnt +=0x03 ; ferror()  ; }  // 0 && 0 => error 
          else { shift0=SCIO ;    }   }  // 0 && 1 => 1 
  else { 
         dlyhfbit()                 ;    // wait till (3/4) bit
//       dlyhbp()                   ;    // increase delay   
       if(SCIO==1) 
         {err_cnt +=0x03 ;ferror()  ; }  // 1 && 1 => error 
          else { shift0=SCIO ;    }   }  // 1 && 0 => 0 
	     dlyqbit()                  ;    // in both OK cases, wait end of bit   
         bit_count++                ; }  // increment bit counter(repeat for 8b) 
         P1M2=0x0d ; return eep_buf ;    // SDA open drain(return data buf) 
                                      } 
//...........................................................................
   void uni_head(void)	           // for the first command after POR 
  { 
    SCIO=0 ; dlythdr()  ;          // in asm, 20 usec
// dlyhfbit();dlyhfbit();  
    SCIO=1 ; dlystby()  ;          // SCIO=1 for 800 usec ( > 600 usec )  
    SCIO=0 ; dlythdr()  ;  }       // SCIO=0 for  20 usec 
//...........................................................................
   void uni_head2(void)            // for consecutive commands 
  { SCIO = 1 ; dlytss() ;          // SCIO = 1 for 2 x THDR (40us)
    SCIO = 0 ; dlythdr();          // SCIO = 0 for     THDR (20us)                       
                           }    
//...........................................................................
   void uni_wrmns(void)            // uni_wr + MAK + NOSAK 
  { eep_buf=START ; uni_wr()   ;   // stream out START 
     mak() ; nosak()    ;          // master ACK + slave NOACK         
                          } 
//...........................................................................
   void uni_wrms(unsigned char ms) // uni_wr + MAK + SAK  
  {  eep_buf=ms ; uni_wr()    ;    // stream out 'eep_buf' previously loaded
     mak() ; sak()      ; }        // master ACK + slave ACK  
//...........................................................................
  void uni_wrnms(unsigned char nms)// uni_wr + MAK + SAK  
  { eep_buf=nms ; uni_wr()     ;   // stream out 'eep_buf' previously loaded 
     nomak() ; sak()    ; }        // master NOACK + slave ACK  
//...........................................................................
 void uni_cmnd(unsigned char cmnd) // WREN , WRDI , ERAL , SETAL - first cmnd  
 { uni_head()           ;          // perform the header of the protocol  
   uni_wrmns()          ;          // wr(START) + mak + nosak   
   uni_wrms(DEVADR)     ;          // wr(DEVADR) + mak +   sak 
   uni_wrnms(cmnd)      ;    }     // end with : wr(cmnd) + nomak + sak 
                                   // ERAL + SETAL need WREN + 10ms
//...........................................................................
void uni_cmnd2(unsigned char cmnd) // WREN , WRDI , ERAL , SETAL  
 { uni_head2()          ;          // perform the header - consecutive cmnds 
   uni_wrmns()          ;          // wr(START) + mak + nosak   
   uni_wrms(DEVADR)     ;          // wr(DEVADR) + mak +   sak 
   uni_wrnms(cmnd)      ;    }     // end with : wr(cmnd) + nomak + sak 
                                   // ERAL + SETAL need WREN + 10ms
//...........................................................................
 void uni_eral(void)  			   // as first command 
 { 	uni_cmnd(WREN)       ; 		   // ERAL needs WREN 
    uni_cmnd(ERAL)       ;		   // ERAL command 
	dly5ms()             ; 		   // 10 ms WCT 
	dly5ms()             ;   }     // not tested in 'C' ; see the asm app note 
//...........................................................................
 void uni_eral2(void)  			   // as consecutive command
 { 	uni_cmnd2(WREN)      ; 		   // ERAL needs WREN 
    uni_cmnd2(ERAL)      ;		   // ERAL command 
	dly5ms()             ; 		   // 10 ms WCT 
	dly5ms()             ;   }     // not tested in 'C' ; see the asm app note      
//...........................................................................
 void uni_setal(void)  			   // as first command 
 {  uni_cmnd(WREN)       ;         // SETAL needs WREN 
    uni_cmnd(SETAL)      ; 		   // SETAL command  
	dly5ms()             ; 		   // 10 ms WCT  
	dly5ms()             ;              
                             }     // not tested in 'C' ; see the asm app note 
//...........................................................................
void uni_setal2(void)  			   // as consecutive command 
 {  uni_cmnd2(WREN)      ;         // SETAL needs WREN 
    uni_cmnd2(SETAL)     ; 		   // SETAL command  
	dly5ms()             ; 		   // 10 ms WCT  
	dly5ms()             ;              
                             }     // not tested in 'C ; see the asm app note    
//...........................................................................
 void uni_wrsr(unsigned char stat) // write to status register   
 { uni_head()           ;          // header - first command  
   err_cnt = 0x00       ;          // error counter for START  
   uni_wrmns()          ;          // wr(START) + mak + nosak 
   err_cnt = 0x04       ;          // error counter for DEVADR   
   uni_wrms(DEVADR)     ;          // wr(DEVADR) + mak +   sak 
   err_cnt = 0x08       ;          // error counter for WRSR command 
   uni_wrms(WRSR)       ;          // wr(WRSR)  + mak + sak    
   err_cnt = 0x0c       ;          // error counter for data(NOPROT) 
   uni_wrnms(stat)      ;          // end with : wr(stat) + nomak + sak 
   dly5ms()             ;   }      // WRSR needs 5ms WCT     
//...........................................................................
  void ini_unio(void) 			   // init UNIO memory 
  { uni_wrsr(NOPROT)    ;          // write in status NOPROT=00 
                             }     // disable all write protections 
//...........................................................................
 unsigned char uni_rdsr(void)      // read the status register 
 { uni_head2()          ;          // header for consecutive  
   uni_wrmns()          ;          // wr(START) + mak + nosak   
   uni_wrms(DEVADR)     ;          // wr(DEVADR) + mak + sak  
   uni_wrms(RDSR)       ;          // wr(RDSR) + mak + sak 
   uni_rdq()            ;          // eep_buf = status reg  
   nomak()  ; sak()     ;          // master NOACK + slave ACK 
   return eep_buf       ;    }     // return the result of uni_rdq   
//...........................................................................
      void uni_wrbyte(unsigned int eep_adr, unsigned char eep_data)  
      {                                //  writes a byte at the spec adr
	     err_cnt = 0x10             ;  //  errors for WREN(WRBYTE)(10h/11h) 
         uni_cmnd2(WREN)            ;  //  first, enable writes 
         uni_head2()                ;  //  header for consecutive cmnds 
		 err_cnt = 0x14             ;  //  error for START (14h/16h)   
         uni_wrmns()                ;  //  wr(START) + mak + nosak
		 err_cnt = 0x18             ;  //  error for DEVADR : 18h/19h   
         uni_wrms(DEVADR)           ;  //  wr(DEVADR) + mak + sak
		 err_cnt = 0x1c             ;  //  error for WRITE : 1Ch/1Dh   
         uni_wrms(WRITE)            ;  //  wr(WRITE)  + mak + sak 
		 err_cnt = 0x20             ;  //  error for adr_high : 20h/21h  
         uni_wrms(eep_adr>>8)       ;  //  wr(high adr) + mak + sak 
		 err_cnt = 0x24             ;  //  error for adr_low : 24h/25h       
         uni_wrms(eep_adr&0xff)     ;  //  wr(low adr) + mak + sak 
		 err_cnt = 0x28             ;  //  error for wr_byte : 28h/29h   
         uni_wrnms(eep_data)        ;  //  end with : wr + nomak + sak 
         dly5ms()                   ;  // write cycle time after each byte 
  //     uni_wippol()               ;  // replace Twc with WIP polling 
                                        } 
//............................................................................
         void uni_rdbyte(unsigned int eep_adr,unsigned char *dst) 
      {                                //  reads a byte from the spec adr 
	     err_cnt = 0x4c             ;  //  error for START : 4ch,4eh 
         uni_head2()                ;  //  header of the protocol  
         uni_wrmns()                ;  //  wr(START) + mak + nosak
		 err_cnt = 0x50      		;  //  error for DEVADR : 50h,51h
         uni_wrms(DEVADR)           ;  //  wr + mak + sak
		 err_cnt = 0x54             ;  //  error for READ : 54h,55h   
         uni_wrms(READ)             ;  //  wr + mak + sak
		 err_cnt = 0x58             ;  //  error for MSB adr : 58h,59h   
         uni_wrms(eep_adr>>8)       ;  //  wr(high adr) + mak + sak
		 err_cnt = 0x5c             ;  //  error for LSB adr : 5ch,5dh        
         uni_wrms(eep_adr&0xff)     ;  //  wr(low adr) + mak + sak 
		 err_cnt = 0x60             ;  //  err for rd_byte : 60h,61h,63h   
         *dst = uni_rdq()           ;  //  store the read data byte  
         nomak()   ;   sak()        ;  //  end with : nomak + sak             
                                        } 
//............................................................................
         void uni_crrdbyte(unsigned char *dst) 	// not tested 
      {                                //  reads a byte from the crt adr 
         uni_head2()                ;  //  header of the protocol  
         uni_wrmns()                ;  //  wr(START) + mak + nosak  
         uni_wrms(DEVADR)           ;  //  wr + mak + sak 
         uni_wrms(CRRD)             ;  //  wr + mak + sak   
         *dst = uni_rdq()           ;  //  store the read data byte  
         nomak()   ;   sak()        ;  //  end with : nomak + sak  
                                    }  //  not tested in 'C' ; see the asm app note 
//...............................................................................
  void uni_wrstr(unsigned char *source,unsigned int eep_adr,unsigned char lofsstr)
  {                                   // writes a string at the spec addr
     unsigned char k = 0            ; // init char counter 
     copystr(load,source,lofsstr)   ; // copy src_str in an internal string  
	 err_cnt = 0x2c                 ; // errors for WREN(WRSTR):2ch,2dh,2eh 
     uni_cmnd2(WREN)                ; // enable writes 
     uni_head2()                    ; // header for consecutive commands 
	 err_cnt = 0x30                 ; // error for START : 30h,32h 
     uni_wrmns()                    ; // wr_START + mak + nosak
	 err_cnt = 0x34                 ; // error for DEVADR : 34h,35h   
     uni_wrms(DEVADR)               ; // wr + mak + sak
	 err_cnt = 0x38                 ; // error for WRITE : 38h,39h   
     uni_wrms(WRITE)                ; // wr + mak + sak
	 err_cnt = 0x3c                 ; // error for MSB adr : 3ch,3dh  
     uni_wrms(eep_adr>>8)           ; // wr(high adr) + mak + sak
	 err_cnt = 0x40                 ; // error for LSB adr : 40h,41h        
     uni_wrms(eep_adr&0xff)         ; // wr(low adr) + mak + sak
//   if(lofsstr==1)                 ; // if single byte, wait last operation
//   else { 						  // strings > 1 byte 
	        err_cnt = 0x44          ; // error for (n-1) bytes : 44h,45h 
	        while(k<lofsstr-1)        // for (n-1) bytes  
       { uni_wrms(load[k]) ; k++  ; } // wr(byte) + mak + sak 
//			                        } // increment pointer & counter 
	 err_cnt = 0x48                 ; // error for the last byte:48h,49h        
     uni_wrnms(load[k])             ; // wr + nomak + sak 
     dly5ms()                       ; // final write cycle time 
//   uni_wippol()                   ; // POLLING WIP 
                               }          
//.............................................................................
  void uni_rdstr(unsigned char *dest,unsigned int eep_adr,unsigned char lofdstr)
      {                               // reads a string from the spec addr   
     unsigned char k = 0 ;          ; // init char counter inside the string 
	 err_cnt = 0x64                 ; // error for START : 64h,66h  
     uni_head2()                    ; // header for consecutive commands 	   
     uni_wrmns()                    ; // wr + mak + nosak
	 err_cnt = 0x68                 ; // error for DEVADR : 68h,69h  
     uni_wrms(DEVADR)               ; // wr + mak + sak
	 err_cnt = 0x6c                 ; // error for READ   
     uni_wrms(READ)                 ; // wr + mak + sak
	 err_cnt = 0x70                 ; // error for MSB adr : 70h,71h   
     uni_wrms(eep_adr>>8)           ; // wr(high adr) + mak + sak
	 err_cnt = 0x74                 ; // error for LSB adr : 74h,75h        
     uni_wrms(eep_adr&0xff)         ; // wr(low adr) + mak + sak
//   if(lofdstr==1) ;                 // if single byte, wait last operation
//   else { 						  // strings > 1 byte 
	        err_cnt = 0x78          ; // error for rd(n-1) bytes:78h,79h,7bh 
	        while(k<lofdstr-1)        // for (n-1) bytes  
      { uni_rdq() ; mak()  ; sak()  ; // read bytes + mak + sak         
        load[k]=eep_buf  ;  k++   ; } // load char with read value ; inc counter  
//			                        }  
	  err_cnt = 0x7c                ; // error for rd last byte : 7ch,7dh,7fh       
      uni_rdq() ; nomak()  ;  sak() ; // read last byte ; nomak + sak 
	  load[k]=eep_buf               ; // load last read char 
	  copystr(dest,load,lofdstr)    ; // copy internal string --> destination               
                                    } 
//..............................................................................
   void uni_crrdstr(unsigned char *dest,unsigned char lofdstr) // not tested 
      {                               // reads a string from the crt adr 
     unsigned char k = 0 ;          ; // init char counter inside the string  
     uni_head2()                    ; // header for consecutive commands   
     uni_wrmns()                    ; // wr + mak + nosak  
     uni_wrms(DEVADR)               ; // wr + mak + sak 
     uni_wrms(CRRD)                 ; // wr + mak + sak 
     if(lofdstr==1)                 ; // if single byte, wait last operation
     else { while(k<lofdstr-1)        // for (n-1) bytes  
            { *dest = uni_rdq()     ; // read bytes      
              mak()    ;   sak()    ; // mak + sak   
              dest++   ; k++    ; } } // increment pointer & counter        
     *dest = uni_rdq()              ; // read last byte
      nomak()      ;    sak()       ; // end with nomak + sak             
                                    } // not tested in 'C' ; see the asm app note 

//****************************************************************************
//               AUXILIARY  FUNCTIONS  DEFINITIONS 
//****************************************************************************
   void dlyusec(unsigned char num_usec) // delay in usec - timer based
// Since 8051_Timers in mode2 work on 8 bits,the argument of the function
// may not override "255" . Accordingly , "num_usec" may not override "64" . 
       { TR0 = 0                    ; // stop timer 
	     TF0 = 0                    ; // clear end flag 
	     TL0 = ~(4*(num_usec-4))    ; // timers<-PCLK=CCLK:2=7.373Mhz:2-> 271ns
		                              // estimate : 4us loss, as in asm   
         TR0 = 1                    ; // start T0 
         while(!TF0)                ; // wait overflow 
                                     } 
//............................................................................
    void calctl0(void)          //  calculates quarter / half bit  
  { tlqb = ~(4*(QBUSEC-2))  ;   //  quarter bit:estimate 2us loss, as in asm 
//  tlhb = ~(4*(2*QBUSEC-2));   //  half    bit:the same formula   as in asm 
	tlhb = ~(4*(2*QBUSEC-1));   //  decrease half bit 
	                        }  
//............................................................................
    void dlyhfbit(void)         //  half bit delay 
  { TR0 = 0                 ;   //  stop  timer 
    TF0 = 0                 ;  	//  clear end flag 
	TL0 = tlhb              ;   //  load fast half bit value 
	TR0 = 1                 ;   //  start  timer 
	while(!TF0)             ;   //  wait overflow 
                                    } 
//............................................................................
     void dlyhbp(void) 		    // half bit plus 
  { TR0 = 0                 ;   //  stop  timer 
    TF0 = 0                 ;  	//  clear end flag 
	TL0 = tlhb-12           ;   //  load fast half bit value 
	TR0 = 1                 ;   //  start  timer 
	while(!TF0)             ;   //  wait overflow 
                                    } 
//............................................................................
    void dlyqbit(void)          //  quarter bit delay 
  { TR0 = 0                 ;   //  stop  timer 
    TF0 = 0                 ;  	//  clear end flag 
	TL0 = tlqb              ;   //  load fast half bit value 
	TR0 = 1                 ;   //  start  timer 
	while(!TF0)             ;   //  wait overflow 
                                    } 				       
//............................................................................
    void dlythdr(void)         	// THDR - SCIO=0 before START 
  { dlyusec(20) ; }             // SCIO=0 20 usec ( as in asm ) 
//............................................................................
    void dlytss(void) 			// TSS - SCIO=1 for consecutive comnds 
  { dlythdr(); dlythdr();}      // as in asm.  
//............................................................................
    void dlystby(void) 			   // header for the first command 
  { unsigned char j = 40 ; 
    while(--j) { dlyusec(20) ; } } // SCIO=1 - 800 usec ( > 600 usec )  
//............................................................................
    void dly5ms(void)                 // 5 miliseconds delay 
  { unsigned char j = 100      ;      // 100 * 50usec = 5 msec 
    while(--j) { dlyusec(50)   ; }  
                                   }
//............................................................................
   void uni_wippol(void)              // wait WIP flag to go down  
   {   while(uni_rdsr()&0x01)  ;   }  // WIP flag = bit0 in SR 
                                      // may replace WCT  
//............................................................................
    void dly250ms(void)               // 250 miliseconds delay 
  { unsigned char k = 50       ;      //  50 * 5 msec = 250 msec 
    while(--k) { dly5ms()      ; }    // usefull for messages' display
                                   }  
//.............................................................................
    void dly1s(void)                  // 1 second delay  
  { dly250ms() ; dly250ms()    ;      // 4 * 250 ms = 1 second 
    dly250ms() ; dly250ms()    ;   }  // usefull for messages' display
//.............................................................................
       void tx_com1(unsigned char com1_buf)  // sends on UART1 line com1_buf  
       {                              //  TI1 = set in S1CON init 
//       while(!(S1CON&0x02))  ;      //  wait for TI_1 = 1 
//       S1CON &= 0xfd         ;      //  clear TI_1 
         while(!(S1CONX&0x02)) ; 
		 S1CONX &=0xfd         ;   
         S1BUF = com1_buf      ;      //  write data in serial data buffer                 
                                   } 
// ............................................................................. 
      void ferror(void) 
  { while(1)                          // for ever 
    { P5=err_cnt ; dly1s() ;          // flash err_cnt 
      P5=0x00    ; dly1s() ; } }      // + 00  

//***************************************************************************** 
   void copystr(unsigned char dest[], unsigned char source[], unsigned char str_size)
   { unsigned char n ; 
     for(n=0;n<str_size;n++) 
	 { dest[n] = source[n] ; } 
//	    calctl0() ; 
		                    }
//..............................................................................        