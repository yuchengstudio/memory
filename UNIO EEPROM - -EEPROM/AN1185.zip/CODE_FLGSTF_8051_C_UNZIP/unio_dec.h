//  UNIO_DEC.h  
 //............................................................................
 //  FUNCTIONS DECLARATIONS 
 //............................................................................
 // File Name    : unio_dec.h 
 // Dependencies : REG952.h     = SFRs definitions offered by "Keil" 
 //                STARTUP950   = start-up code for LPC952 ( "Keil" )  
 // Processor    : P89LPC952  
 // Hardware     : MicroChip's UNIO EEPROM = 11XXXX on MCB950 EVB . 
 // I.D.E.       : uVision3 - Keil 
 // Company      : MicroChip Technology , Inc.
 // Author       : Alexandru Valeanu 
 //...........................................................................
 //                          SOFTWARE  LICENSE AGREEMENT 
 //...........................................................................
 // "Microchip Technology Inc. (�Microchip�) licenses this software to you 
 // solely for use with Microchip Serial EEPROM products. 
 // The software is owned by Microchip and/or its licensors,and is protected 
 // under applicable copyright laws.  All rights reserved.
 // SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP AND ITS LICENSOR EXPRESSLY 
 // DISCLAIM ANY WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING 
 // BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS 
 // FOR A PARTICULAR PURPOSE,OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP 
 // AND ITS LICENSORS BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
 // CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, 
 // COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY 
 // CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE 
 // THEREOF),ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS."
 //***************************************************************************
 // History      :  V1.0 - Initial Release 
 //...........................................................................
 // File Description : This is the file declaring all the necessary functions
 //                    for the application note AN1185 . 
 //                    Functions are declared in the below file as external 
 // functions , using formal variables . Accordingly , they will be defined 
 // in the mirror file : unio_def.c. As described, there are 3 types of 
 // functions : initialization , unio_access , auxiliary .                     
 //............................................................................
 //                 INITIALIZATION FUNCTIONS DECLARATIONS  
 //............................................................................
      extern void  ini_intr(void)     ;               // interrupts'    init 
      extern void  ini_wdt(void)      ;               //  W.D.T.'s      init 
      extern void  ini_osc(void)      ;               //  oscillator's  init   
      extern void  ini_gpio(void)     ;               //  GPIO's        init 
      extern void  ini_unio(void)     ;               //  UNIO bit-bang init 
      extern void  ini_com1(void)     ;               //  UART1's       init 
      extern void  ini_tim(void)      ;               //  Timers'       init
      extern void  calctl0(void)      ;               //  TL0           init 
	  extern void  ini_unio(void)     ;        // init mem : WRSR(NOPROT=00)  
 //............................................................................
 //                   UNIO ACCESS FUNCTIONS  DECLARATIONS 
 //............................................................................
    extern void mak(void)                   ; //   ACK from master       
    extern void nomak(void)                 ; // NOACK from master 
    extern void sak(void)                   ; //   ACK from slave
    extern void nosak(void)                 ; // NOACK from slave 
 // no need for uni_wren() : uni_cmnd(WREN)  
 // extern void uni_wr(unsigned char)       ; //  WRITE 8b stream
 // extern void uni_wr(eep_buf)             ; // alternative
	extern void uni_wr(void)                ; // writes an 8b streaming 
//  extern unsigned char uni_rd(void)       ; //  READ  8b stream
	extern unsigned char uni_rdq(void)      ; //read stream based on QB   
    extern void uni_wrbyte(unsigned int , unsigned char); //  WRITE data byte 
    extern void uni_rdbyte(unsigned int,unsigned char*) ; //  READ  data byte
    extern void uni_crrdbyte(unsigned char*)            ; //  READ  data byte 
                                                          //  from crt address  
    extern void uni_wrstr(unsigned char*,unsigned int,unsigned char);
                                                           //  WRITE STRING 
    extern void uni_rdstr(unsigned char*,unsigned int,unsigned char);
                                                           //  READ STRING
    extern void uni_crrdstr(unsigned char*,unsigned char) ; // READ STRING 
                                                            // from crt address  
    extern void uni_cmnd(unsigned char)      ; //  writes a single byte instruction
	extern void uni_cmnd2(unsigned char)     ; //  sg byte instr for consec cmnds 
	extern void uni_eral(void)               ; //  erase entire array (00)
	extern void uni_eral2(void)              ; //  erase as consec cmnd  
	extern void uni_setal(void)              ; //  set   entire array (ff)
	extern void uni_setal2(void)             ; //  set   as consec cmnd   
    extern void uni_wrsr(unsigned char)      ; //  writes in the status reg 
    extern unsigned char uni_rdsr(void)      ; //  reads from the status reg  
    extern void uni_head(void)               ; // UNIO header 
	extern void uni_head2(void)              ; // UNIO header for consec cmnds  
    extern void uni_wrmns(void)         ; // wr +   mak + nosak             
    extern void uni_wrms(unsigned char) ; // wr +   mak +   sak 
    extern void uni_wrnms(unsigned char); // wr + nomak +   sak 
//.................................................................................
//             AUXILIARY  FUNCTIONS  DECLARATIONS 
//................................................................................. 
      extern void dlyusec(unsigned char)       ; // delay in <usec> 
      extern void dlyhfbit(void)               ; // half bit 
	  extern void dlyhbp(void)                 ; // half bit plus (MAK/NOMAK)
	  extern void dlyqbit(void)                ; // quarter bit  
      extern void dlythdr(void)                ; // SCIO=0 for 20 usec 
      extern void dlytss(void)                 ; // SCIO=1 for 40 usec, cons cmnds 
      extern void dlystby(void)                ; // SCIO=1 for 800usec( >600usec )   
      extern void dly5ms(void)                 ; // 5 msec delay 
	  extern void uni_wippol(void)             ; // wait WIP rise-up 
      extern void dly250ms(void)               ; // 250 msec delay 
      extern void dly1s(void)                  ; // 1 sec delay     
      extern void tx_com1(unsigned char)       ; // tx byte on UART1 
      extern void ferror(void)                 ; // final error 
	  extern void copystr(unsigned char*, unsigned char*, unsigned char) ; 
	                                             // copy a string : src-->dst  